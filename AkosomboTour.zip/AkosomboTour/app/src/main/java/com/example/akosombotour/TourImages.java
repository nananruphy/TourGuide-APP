package com.example.akosombotour;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class TourImages extends Activity {
    private Bitmap mImage1;

    public static void setOnClickListener(View.OnClickListener onClickListener) {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tour_images);



        Bundle bundle = getIntent().getExtras();
        ImageView imageView = (ImageView) findViewById(R.id.akosombodam_imageview);
    }
}

package com.example.akosombotour;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class TourImages1 extends Activity {
    private Bitmap mImage1;

    public static void setOnClickListener(View.OnClickListener onClickListener) {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tour_images_1);


        Bundle bundle = getIntent().getExtras();
        ImageView imageView = (ImageView) findViewById(R.id.adomi_imageview);
    }
}
